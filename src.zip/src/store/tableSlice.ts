import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { TableState, TableRow, Column, SortConfig } from '../types';

const defaultColumns: Column[] = [
  { id: 'name', label: 'Name', visible: true, sortable: true },
  { id: 'email', label: 'Email', visible: true, sortable: true },
  { id: 'age', label: 'Age', visible: true, sortable: true },
  { id: 'role', label: 'Role', visible: true, sortable: true },
  { id: 'department', label: 'Department', visible: false, sortable: true },
  { id: 'location', label: 'Location', visible: false, sortable: true },
];

const sampleData: TableRow[] = [
  { id: '1', name: 'John Doe', email: 'john@example.com', age: 30, role: 'Developer', department: 'Engineering', location: 'New York' },
  { id: '2', name: 'Jane Smith', email: 'jane@example.com', age: 28, role: 'Designer', department: 'Design', location: 'San Francisco' },
  { id: '3', name: 'Bob Johnson', email: 'bob@example.com', age: 35, role: 'Manager', department: 'Engineering', location: 'Seattle' },
  { id: '4', name: 'Alice Brown', email: 'alice@example.com', age: 32, role: 'Developer', department: 'Engineering', location: 'Austin' },
  { id: '5', name: 'Charlie Wilson', email: 'charlie@example.com', age: 29, role: 'Designer', department: 'Design', location: 'Los Angeles' },
];

const initialState: TableState = {
  data: sampleData,
  columns: defaultColumns,
  searchTerm: '',
  sortConfig: null,
  currentPage: 0,
  rowsPerPage: 10,
  editingRows: new Set(),
};

const tableSlice = createSlice({
  name: 'table',
  initialState,
  reducers: {
    setData: (state, action: PayloadAction<TableRow[]>) => {
      state.data = action.payload;
    },
    addRow: (state, action: PayloadAction<TableRow>) => {
      state.data.push(action.payload);
    },
    updateRow: (state, action: PayloadAction<{ id: string; data: Partial<TableRow> }>) => {
      const index = state.data.findIndex(row => row.id === action.payload.id);
      if (index !== -1) {
        state.data[index] = { ...state.data[index], ...action.payload.data };
      }
    },
    deleteRow: (state, action: PayloadAction<string>) => {
      state.data = state.data.filter(row => row.id !== action.payload);
    },
    setColumns: (state, action: PayloadAction<Column[]>) => {
      state.columns = action.payload;
    },
    toggleColumnVisibility: (state, action: PayloadAction<string>) => {
      const column = state.columns.find(col => col.id === action.payload);
      if (column) {
        column.visible = !column.visible;
      }
    },
    addColumn: (state, action: PayloadAction<Column>) => {
      state.columns.push(action.payload);
    },
    setSearchTerm: (state, action: PayloadAction<string>) => {
      state.searchTerm = action.payload;
      state.currentPage = 0;
    },
    setSortConfig: (state, action: PayloadAction<SortConfig | null>) => {
      state.sortConfig = action.payload;
    },
    setCurrentPage: (state, action: PayloadAction<number>) => {
      state.currentPage = action.payload;
    },
    setRowsPerPage: (state, action: PayloadAction<number>) => {
      state.rowsPerPage = action.payload;
      state.currentPage = 0;
    },
    toggleEditingRow: (state, action: PayloadAction<string>) => {
      const newSet = new Set(state.editingRows);
      if (newSet.has(action.payload)) {
        newSet.delete(action.payload);
      } else {
        newSet.add(action.payload);
      }
      state.editingRows = newSet;
    },
    clearEditingRows: (state) => {
      state.editingRows = new Set();
    },
  },
});

export const {
  setData,
  addRow,
  updateRow,
  deleteRow,
  setColumns,
  toggleColumnVisibility,
  addColumn,
  setSearchTerm,
  setSortConfig,
  setCurrentPage,
  setRowsPerPage,
  toggleEditingRow,
  clearEditingRows,
} = tableSlice.actions;

export default tableSlice.reducer;