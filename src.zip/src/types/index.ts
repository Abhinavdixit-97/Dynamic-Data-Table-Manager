export interface TableRow {
  id: string;
  name: string;
  email: string;
  age: number;
  role: string;
  department?: string;
  location?: string;
  [key: string]: any;
}

export interface Column {
  id: string;
  label: string;
  visible: boolean;
  sortable: boolean;
}

export interface SortConfig {
  key: string;
  direction: 'asc' | 'desc';
}

export interface TableState {
  data: TableRow[];
  columns: Column[];
  searchTerm: string;
  sortConfig: SortConfig | null;
  currentPage: number;
  rowsPerPage: number;
  editingRows: Set<string>;
}