'use client';
import React, { useState, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  TextField,
  Box,
  Button,
  IconButton,
  TableSortLabel,
  Chip,
  Alert,
} from '@mui/material';
import {
  Add as AddIcon,
  FileUpload as UploadIcon,
  FileDownload as DownloadIcon,
  ViewColumn as ColumnIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Save as SaveIcon,
  Cancel as CancelIcon,
} from '@mui/icons-material';
import { RootState } from '../store/store';
import {
  setSearchTerm,
  setSortConfig,
  setCurrentPage,
  setRowsPerPage,
  setData,
  updateRow,
  deleteRow,
  toggleEditingRow,
  clearEditingRows,
} from '../store/tableSlice';
import { TableRow as TableRowType } from '../types';
import { parseCSV, exportToCSV } from '../utils/csvUtils';
import ManageColumnsModal from './ManageColumnsModal';
import EditableCell from './EditableCell';

const DataTable: React.FC = () => {
  const dispatch = useDispatch();
  const { data, columns, searchTerm, sortConfig, currentPage, rowsPerPage, editingRows } = useSelector(
    (state: RootState) => state.table
  );

  const [showColumnsModal, setShowColumnsModal] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const visibleColumns = columns.filter(col => col.visible);

  const filteredAndSortedData = useMemo(() => {
    let filtered = data.filter(row =>
      Object.values(row).some(value =>
        value?.toString().toLowerCase().includes(searchTerm.toLowerCase())
      )
    );

    if (sortConfig) {
      filtered.sort((a, b) => {
        const aVal = a[sortConfig.key];
        const bVal = b[sortConfig.key];
        
        if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return filtered;
  }, [data, searchTerm, sortConfig]);

  const paginatedData = useMemo(() => {
    const startIndex = currentPage * rowsPerPage;
    return filteredAndSortedData.slice(startIndex, startIndex + rowsPerPage);
  }, [filteredAndSortedData, currentPage, rowsPerPage]);

  const handleSort = (columnId: string) => {
    const isAsc = sortConfig?.key === columnId && sortConfig.direction === 'asc';
    dispatch(setSortConfig({
      key: columnId,
      direction: isAsc ? 'desc' : 'asc',
    }));
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      setUploadError(null);
      const csvData = await parseCSV(file);
      dispatch(setData([...data, ...csvData]));
    } catch (error) {
      setUploadError(error instanceof Error ? error.message : 'Failed to parse CSV');
    }
    
    event.target.value = '';
  };

  const handleExport = () => {
    exportToCSV(filteredAndSortedData, columns);
  };

  const handleRowUpdate = (id: string, field: string, value: any) => {
    dispatch(updateRow({ id, data: { [field]: value } }));
  };

  const handleDeleteRow = (id: string) => {
    if (window.confirm('Are you sure you want to delete this row?')) {
      dispatch(deleteRow(id));
    }
  };

  const handleSaveAll = () => {
    dispatch(clearEditingRows());
  };

  const handleCancelAll = () => {
    dispatch(clearEditingRows());
  };

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <Box sx={{ p: 2, display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
        <TextField
          size="small"
          placeholder="Search all fields..."
          value={searchTerm}
          onChange={(e) => dispatch(setSearchTerm(e.target.value))}
          sx={{ minWidth: 200 }}
        />
        
        <Button
          variant="outlined"
          startIcon={<ColumnIcon />}
          onClick={() => setShowColumnsModal(true)}
        >
          Manage Columns
        </Button>
        
        <Button
          variant="outlined"
          component="label"
          startIcon={<UploadIcon />}
        >
          Import CSV
          <input
            type="file"
            accept=".csv"
            hidden
            onChange={handleFileUpload}
          />
        </Button>
        
        <Button
          variant="outlined"
          startIcon={<DownloadIcon />}
          onClick={handleExport}
        >
          Export CSV
        </Button>

        {editingRows.size > 0 && (
          <>
            <Button
              variant="contained"
              startIcon={<SaveIcon />}
              onClick={handleSaveAll}
              color="primary"
            >
              Save All ({editingRows.size})
            </Button>
            <Button
              variant="outlined"
              startIcon={<CancelIcon />}
              onClick={handleCancelAll}
            >
              Cancel All
            </Button>
          </>
        )}
      </Box>

      {uploadError && (
        <Box sx={{ px: 2, pb: 2 }}>
          <Alert severity="error" onClose={() => setUploadError(null)}>
            {uploadError}
          </Alert>
        </Box>
      )}

      <TableContainer sx={{ maxHeight: 600 }}>
        <Table stickyHeader>
          <TableHead>
            <TableRow>
              {visibleColumns.map((column) => (
                <TableCell key={column.id} sx={{ fontWeight: 'bold', backgroundColor: '#f5f5f5' }}>
                  {column.sortable ? (
                    <TableSortLabel
                      active={sortConfig?.key === column.id}
                      direction={sortConfig?.key === column.id ? sortConfig.direction : 'asc'}
                      onClick={() => handleSort(column.id)}
                    >
                      {column.label}
                    </TableSortLabel>
                  ) : (
                    column.label
                  )}
                </TableCell>
              ))}
              <TableCell sx={{ fontWeight: 'bold', backgroundColor: '#f5f5f5' }}>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {paginatedData.map((row) => (
              <TableRow key={row.id} hover>
                {visibleColumns.map((column) => (
                  <TableCell key={column.id}>
                    <EditableCell
                      value={row[column.id]}
                      isEditing={editingRows.has(row.id)}
                      onSave={(value) => handleRowUpdate(row.id, column.id, value)}
                      type={column.id === 'age' ? 'number' : 'text'}
                    />
                  </TableCell>
                ))}
                <TableCell>
                  <IconButton
                    size="small"
                    onClick={() => dispatch(toggleEditingRow(row.id))}
                    color={editingRows.has(row.id) ? 'primary' : 'default'}
                  >
                    <EditIcon />
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => handleDeleteRow(row.id)}
                    color="error"
                  >
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <TablePagination
        rowsPerPageOptions={[5, 10, 25, 50]}
        component="div"
        count={filteredAndSortedData.length}
        rowsPerPage={rowsPerPage}
        page={currentPage}
        onPageChange={(_, newPage) => dispatch(setCurrentPage(newPage))}
        onRowsPerPageChange={(e) => dispatch(setRowsPerPage(parseInt(e.target.value, 10)))}
      />

      <ManageColumnsModal
        open={showColumnsModal}
        onClose={() => setShowColumnsModal(false)}
      />
    </Paper>
  );
};

export default DataTable;