'use client';
import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  FormControlLabel,
  Checkbox,
  TextField,
  Box,
  Typography,
  Divider,
} from '@mui/material';
import { RootState } from '../store/store';
import { toggleColumnVisibility, addColumn } from '../store/tableSlice';
import { Column } from '../types';

interface ManageColumnsModalProps {
  open: boolean;
  onClose: () => void;
}

const ManageColumnsModal: React.FC<ManageColumnsModalProps> = ({ open, onClose }) => {
  const dispatch = useDispatch();
  const { columns } = useSelector((state: RootState) => state.table);
  const [newColumnName, setNewColumnName] = useState('');

  const handleToggleColumn = (columnId: string) => {
    dispatch(toggleColumnVisibility(columnId));
  };

  const handleAddColumn = () => {
    if (newColumnName.trim()) {
      const newColumn: Column = {
        id: newColumnName.toLowerCase().replace(/\s+/g, '_'),
        label: newColumnName,
        visible: true,
        sortable: true,
      };
      dispatch(addColumn(newColumn));
      setNewColumnName('');
    }
  };

  const handleClose = () => {
    setNewColumnName('');
    onClose();
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
      <DialogTitle>Manage Columns</DialogTitle>
      <DialogContent>
        <Typography variant="subtitle2" gutterBottom>
          Show/Hide Columns
        </Typography>
        <Box sx={{ mb: 3 }}>
          {columns.map((column) => (
            <FormControlLabel
              key={column.id}
              control={
                <Checkbox
                  checked={column.visible}
                  onChange={() => handleToggleColumn(column.id)}
                />
              }
              label={column.label}
            />
          ))}
        </Box>
        
        <Divider sx={{ my: 2 }} />
        
        <Typography variant="subtitle2" gutterBottom>
          Add New Column
        </Typography>
        <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
          <TextField
            size="small"
            placeholder="Column name"
            value={newColumnName}
            onChange={(e) => setNewColumnName(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAddColumn()}
            fullWidth
          />
          <Button
            variant="contained"
            onClick={handleAddColumn}
            disabled={!newColumnName.trim()}
          >
            Add
          </Button>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

export default ManageColumnsModal;