'use client';
import React, { useState, useEffect } from 'react';
import { TextField, Typography } from '@mui/material';

interface EditableCellProps {
  value: any;
  isEditing: boolean;
  onSave: (value: any) => void;
  type?: 'text' | 'number' | 'email';
}

const EditableCell: React.FC<EditableCellProps> = ({
  value,
  isEditing,
  onSave,
  type = 'text'
}) => {
  const [editValue, setEditValue] = useState(value);

  useEffect(() => {
    setEditValue(value);
  }, [value, isEditing]);

  const handleBlur = () => {
    let processedValue = editValue;
    
    if (type === 'number') {
      processedValue = parseInt(editValue) || 0;
    }
    
    onSave(processedValue);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleBlur();
    }
  };

  if (!isEditing) {
    return <Typography variant="body2">{value}</Typography>;
  }

  return (
    <TextField
      size="small"
      value={editValue}
      onChange={(e) => setEditValue(e.target.value)}
      onBlur={handleBlur}
      onKeyPress={handleKeyPress}
      type={type}
      autoFocus
      fullWidth
      variant="standard"
    />
  );
};

export default EditableCell;