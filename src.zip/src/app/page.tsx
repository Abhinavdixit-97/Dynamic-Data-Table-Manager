'use client';
import { Container, Typography, Box } from '@mui/material';
import DataTable from '../components/DataTable';

export default function Home() {
  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h3" component="h1" gutterBottom>
          Dynamic Data Table Manager
        </Typography>
        <Typography variant="subtitle1" color="text.secondary">
          Manage your data with sorting, filtering, and dynamic columns
        </Typography>
      </Box>
      <DataTable />
    </Container>
  );
}