'use client';
import { Inter } from 'next/font/google';
import { Provider } from 'react-redux';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { configureStore } from '@reduxjs/toolkit';
import tableReducer from '../store/tableSlice';
import { theme } from '../utils/theme';

const inter = Inter({ subsets: ['latin'] });

const simpleStore = configureStore({
  reducer: {
    table: tableReducer,
  },
});

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Provider store={simpleStore}>
          <ThemeProvider theme={theme}>
            <CssBaseline />
            {children}
          </ThemeProvider>
        </Provider>
      </body>
    </html>
  );
}